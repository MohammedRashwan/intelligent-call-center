#!/bin/bash
chmod +x final-code.sh

# Step 1: Create a new Intelligent Call Center app
echo "Creating an Intelligent Call Center App..."
npx create-react-app intelligent-call-center
cd intelligent-call-center

# Step 2: Install required dependencies
echo "Installing dependencies..."
npm install @mui/material @emotion/react @emotion/styled @azure/communication-calling @azure/communication-chat @azure/communication-identity axios web-vitals

# Step 3: Create CallWithChatComponent.js
echo "Creating CallWithChatComponent.js..."
cat <<EOF > src/CallWithChatComponent.js
import React, { useEffect, useRef, useState } from 'react';
import { Box, Button, Typography, Paper, CircularProgress } from '@mui/material';
import { CommunicationIdentityClient } from '@azure/communication-identity';
import { CallClient, VideoStreamRenderer } from '@azure/communication-calling';
import { ChatClient } from '@azure/communication-chat';
import axios from 'axios';

const CallWithChatComponent = () => {
    const [userToken, setUserToken] = useState('');
    const [chatResponse, setChatResponse] = useState('');
    const [callStatus, setCallStatus] = useState('');
    const [message, setMessage] = useState('');
    const [callClient, setCallClient] = useState(null);
    const [videoRenderer, setVideoRenderer] = useState(null);

    // Initialize the Communication Identity Client
    const identityClient = useRef(new CommunicationIdentityClient('https://project-call-center-acs.unitedstates.communication.azure.com/;accesskey=JHqvHdtEq4cNOYYKBjCHGIvs4IjxKAk9GIXkxrLLFmkMqWP45TVlJQQJ99ALACULyCpRUx4OAAAAAZCS16bC'));
    const chatClient = useRef(null);

    useEffect(() => {
        const initialize = async () => {
            try {
                // Generate a new user token
                const tokenResponse = await axios.post('http://localhost:5000/start-chat', { message: 'Hello' });
                setUserToken(tokenResponse.data.userToken);
                console.log('User Token:', tokenResponse.data.userToken);

                // Initialize the Call Client
                const callClientInstance = new CallClient();
                setCallClient(callClientInstance);

                // Initialize the Chat Client
                chatClient.current = new ChatClient('https://project-call-center-acs.unitedstates.communication.azure.com/;accesskey=JHqvHdtEq4cNOYYKBjCHGIvs4IjxKAk9GIXkxrLLFmkMqWP45TVlJQQJ99ALACULyCpRUx4OAAAAAZCS16bC');
            } catch (error) {
                console.error('Error initializing:', error);
            }
        };

        initialize();
    }, []);

    const handleStartCall = async () => {
        if (!userToken) {
            console.error('User token not available');
            return;
        }
        try {
            const callAgent = await callClient.createCallAgent(userToken);
            const call = await callAgent.startCall([{ id: userToken }]);
            setCallStatus('Call started');
        } catch (error) {
            console.error('Error starting call:', error);
        }
    };

    const handleSendMessage = async () => {
        try {
            const response = await axios.post('http://localhost:5000/start-chat', {
                userToken,
                message,
            });
            setChatResponse(response.data.response);
        } catch (error) {
            console.error('Error sending message:', error);
        }
    };

    return (
        <Box>
            <Typography variant="h4">Intelligent Call Center</Typography>

            {/* Start Call Button */}
            <Paper style={{ padding: 16, marginBottom: 16 }}>
                <Typography variant="h6">Start Call</Typography>
                <Button variant="contained" color="primary" onClick={handleStartCall}>
                    Start Call
                </Button>
                {callStatus && <Typography variant="body1">{callStatus}</Typography>}
            </Paper>

            {/* Chat Section */}
            <Paper style={{ padding: 16 }}>
                <Typography variant="h6">Chat with AI</Typography>
                <input
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Ask a question"
                />
                <Button variant="contained" color="primary" onClick={handleSendMessage}>
                    Send
                </Button>
                {chatResponse && <Typography variant="body1">AI Response: {chatResponse}</Typography>}
            </Paper>

            {/* Loading Spinner */}
            {videoRenderer ? (
                <div>
                    <VideoStreamRenderer renderer={videoRenderer} />
                </div>
            ) : (
                <CircularProgress />
            )}
        </Box>
    );
};

export default CallWithChatComponent;
EOF

# Step 4: Update the App.js to include the new component
echo "Updating App.js..."
cat <<EOF > src/App.js
import React from 'react';
import './App.css';
import CallWithChatComponent from './CallWithChatComponent';

function App() {
  return (
    <div className="App">
      <h1>Intelligent Call Center with Chat</h1>
      <CallWithChatComponent />
    </div>
  );
}

export default App;
EOF

# Step 5: Start the React app
echo "Starting the React app..."